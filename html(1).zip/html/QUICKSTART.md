# 快速启动指南

## 第一步：配置数据库

1. 确保 MySQL 已安装并运行
2. 打开 MySQL 客户端，执行以下命令创建数据库：

```sql
CREATE DATABASE IF NOT EXISTS kale_esports CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

3. 修改 `src/main/resources/application.properties` 中的数据库连接信息：

```properties
spring.datasource.username=root
spring.datasource.password=你的MySQL密码
```

## 第二步：运行项目

### 方式一：使用 Maven 命令行

```bash
# 在项目根目录执行
mvn spring-boot:run
```

### 方式二：使用 IDE

1. 使用 IntelliJ IDEA 或 Eclipse 打开项目
2. 等待 Maven 自动下载依赖
3. 运行 `src/main/java/org/example/Main.java` 的 `main` 方法

## 第三步：访问项目

项目启动后，访问以下地址：

- **首页**: http://localhost:8080/t1/index.html
- **登录页**: http://localhost:8080/t1/login.html
- **注册页**: http://localhost:8080/t1/register.html
- **充值页**: http://localhost:8080/t1/recharge.html

## 第四步：测试功能

### 1. 注册账号

1. 访问注册页面
2. 填写用户名、密码等信息
3. 点击注册

### 2. 登录

1. 访问登录页面
2. 输入刚才注册的用户名和密码
3. 点击登录

### 3. 充值

1. 登录后，点击导航栏的"充值"按钮
2. 选择充值金额和支付方式
3. 点击"立即充值"
4. 在充值记录中点击"确认充值"（模拟支付成功）

## 常见问题

### 1. 端口被占用

如果 8080 端口被占用，修改 `application.properties` 中的 `server.port`：

```properties
server.port=8081
```

### 2. 数据库连接失败

- 检查 MySQL 是否运行
- 检查数据库用户名和密码是否正确
- 检查数据库 `kale_esports` 是否已创建

### 3. 前端页面无法访问后端 API

- 确保后端服务已启动
- 检查浏览器控制台是否有跨域错误
- 确认 API 地址为 `http://localhost:8080/api`

### 4. 表结构未自动创建

如果表结构未自动创建，可以手动执行 `src/main/resources/db/schema.sql` 脚本。

## 下一步

- 查看 `README.md` 了解完整的项目文档
- 查看 API 接口文档了解所有可用接口
- 根据需要修改配置和功能

