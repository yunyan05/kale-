package org.example.controller;

import org.example.dto.ApiResponse;
import org.example.dto.RechargeRequest;
import org.example.entity.Recharge;
import org.example.service.RechargeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/recharge")
@CrossOrigin(origins = "*")
public class RechargeController {
    @Autowired
    private RechargeService rechargeService;

    @PostMapping("/create")
    public ApiResponse<Recharge> createRecharge(
            @RequestParam Long userId,
            @Valid @RequestBody RechargeRequest request) {
        try {
            Recharge recharge = rechargeService.createRecharge(userId, request);
            return ApiResponse.success("充值订单创建成功", recharge);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage());
        }
    }

    @PostMapping("/confirm/{rechargeId}")
    public ApiResponse<Recharge> confirmRecharge(@PathVariable Long rechargeId) {
        try {
            Recharge recharge = rechargeService.confirmRecharge(rechargeId);
            return ApiResponse.success("充值成功", recharge);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage());
        }
    }

    @GetMapping("/list/{userId}")
    public ApiResponse<List<Recharge>> getUserRecharges(@PathVariable Long userId) {
        try {
            List<Recharge> recharges = rechargeService.getUserRecharges(userId);
            return ApiResponse.success(recharges);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage());
        }
    }

    @GetMapping("/{rechargeId}")
    public ApiResponse<Recharge> getRecharge(@PathVariable Long rechargeId) {
        try {
            Recharge recharge = rechargeService.getRechargeById(rechargeId);
            return ApiResponse.success(recharge);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage());
        }
    }
}

