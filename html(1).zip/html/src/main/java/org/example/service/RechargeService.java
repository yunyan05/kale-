package org.example.service;

import org.example.dto.RechargeRequest;
import org.example.entity.Recharge;
import org.example.entity.User;
import org.example.repository.RechargeRepository;
import org.example.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class RechargeService {
    @Autowired
    private RechargeRepository rechargeRepository;

    @Autowired
    private UserRepository userRepository;

    @Transactional
    public Recharge createRecharge(Long userId, RechargeRequest request) {
        // 验证用户存在
        userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));

        Recharge recharge = new Recharge();
        recharge.setUserId(userId);
        recharge.setAmount(request.getAmount());
        recharge.setPaymentMethod(request.getPaymentMethod());
        recharge.setStatus("PENDING");
        recharge.setTransactionId(UUID.randomUUID().toString().replace("-", ""));

        return rechargeRepository.save(recharge);
    }

    @Transactional
    public Recharge confirmRecharge(Long rechargeId) {
        Recharge recharge = rechargeRepository.findById(rechargeId)
                .orElseThrow(() -> new RuntimeException("充值记录不存在"));

        if (!"PENDING".equals(recharge.getStatus())) {
            throw new RuntimeException("充值记录状态不正确");
        }

        User user = userRepository.findById(recharge.getUserId())
                .orElseThrow(() -> new RuntimeException("用户不存在"));

        // 更新用户余额
        user.setBalance(user.getBalance().add(recharge.getAmount()));
        userRepository.save(user);

        // 更新充值状态
        recharge.setStatus("SUCCESS");
        return rechargeRepository.save(recharge);
    }

    public List<Recharge> getUserRecharges(Long userId) {
        return rechargeRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public Recharge getRechargeById(Long rechargeId) {
        return rechargeRepository.findById(rechargeId)
                .orElseThrow(() -> new RuntimeException("充值记录不存在"));
    }
}

