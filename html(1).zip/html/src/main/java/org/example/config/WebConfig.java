package org.example.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .maxAge(3600);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 优先映射 /t1/** 到 classpath:/html/t1/
        registry.addResourceHandler("/t1/**")
                .addResourceLocations("classpath:/html/t1/")
                .setCachePeriod(0);
        // 映射其他静态资源到 classpath:/html/
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/html/")
                .setCachePeriod(0);
    }
}

